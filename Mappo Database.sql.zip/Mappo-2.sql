-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 19, 2025 at 06:31 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Mappo`
--

-- --------------------------------------------------------

--
-- Table structure for table `measurements`
--

CREATE TABLE `measurements` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `area` double NOT NULL DEFAULT 0,
  `perimeter` double NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL DEFAULT '""',
  `place` varchar(255) NOT NULL DEFAULT '""',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `measurements`
--

INSERT INTO `measurements` (`id`, `user_id`, `area`, `perimeter`, `unit`, `place`, `created_at`) VALUES
(30, 1, 0, 47127.63, 'meters', 'Unknown', '2025-02-25 06:55:35'),
(31, 1, 397.578243, 81.06, 'kilometers', 'Unknown', '2025-02-25 06:57:59'),
(32, 1, 23300.19, 46665.02, 'acres', 'Unknown', '2025-02-25 08:25:12'),
(33, 1, 59808.49, 65141.17, 'acres', 'Unknown', '2025-02-25 08:25:59'),
(34, 1, 72712.63, 70260.5, 'acres', 'Unknown', '2025-02-25 10:04:54'),
(35, 1, 45835.2, 56139.59, 'acres', 'Unknown', '2025-02-25 10:24:01'),
(36, 20, 206317.89405205662, 3089.699477809024, 'square_meter', 'chennai', '2025-02-26 05:15:39'),
(37, 20, 190725.34443296742, 2109.132943547319, 'square_feet', 'arani', '2025-02-26 05:16:52'),
(38, 20, 1087499.7052954037, 5935.496633712077, 'square_meter', 'hello', '2025-02-26 06:16:29'),
(39, 20, 1954709.818074498, 6078.76747447032, 'acre', 'acre', '2025-02-26 06:16:57'),
(40, 20, 0, 2618.6610614747365, 'square_meter', 'jillo', '2025-02-26 06:18:43'),
(41, 20, 442128.28881531354, 2694.169149810601, 'square_meter', 'gg', '2025-02-26 06:19:54'),
(42, 20, 9025.7515243027, 3291.3986310207624, 'square_meter', 'bg', '2025-02-26 06:20:27'),
(43, 1, 1946296.49, 5632.39, 'meters', 'Unknown', '2025-02-26 06:37:35'),
(44, 1, 1946296.49, 5632.39, 'meters', 'Unknown', '2025-02-26 06:37:36'),
(45, 1, 1197567.22, 316064, 'acres', 'Unknown', '2025-02-26 06:39:37'),
(46, 1, 1197567.22, 316064, 'acres', 'Unknown', '2025-02-26 06:39:50'),
(47, 1, 1197567.22, 316064, 'acres', 'Unknown', '2025-02-26 06:39:51'),
(48, 1, 600913003.92, 125511.59, 'meters', 'Unknown', '2025-02-26 06:41:25'),
(49, 1, 94879.21, 94199.35, 'acres', 'Unknown', '2025-02-26 06:45:02'),
(50, 1, 500.5, 120.3, 'sq_feet', 'New York', '2025-02-26 06:49:42'),
(51, 1, 419059.05, 2508.86, 'meters', 'Unknown', '2025-02-26 06:51:16'),
(52, 1, 419059.05, 2508.86, 'meters', 'Unknown', '2025-02-26 06:53:07'),
(53, 1, 500.5, 120.3, 'sq_feet', 'New York', '2025-02-26 06:54:47'),
(54, 1, 500.5, 120.3, 'sq_feet', 'New York', '2025-02-26 06:54:48'),
(55, 21, 882424.3435589598, 4634.314241302531, 'square_meter', 'new', '2025-02-26 06:55:47'),
(56, 21, 643692.5287904892, 3780.5195311384796, 'acre', 'ghk', '2025-02-26 06:56:34'),
(57, 21, 264384.42828732915, 3386.8473211632468, 'acre', 'jvg', '2025-02-26 06:58:01'),
(58, 1, 87.03, 2268.21, 'acres', 'Unknown', '2025-02-26 06:58:12'),
(59, 1, 157236474.67, 49389.26, 'meters', 'Unknown', '2025-03-17 09:38:36'),
(60, 1, 229489301.03, 61777.25, 'meters', 'Unknown', '2025-03-17 09:41:16'),
(61, 1, 256769720.88, 63328.25, 'meters', 'Unknown', '2025-03-17 09:41:54'),
(62, 1, 256769720.88, 63328.25, 'meters', 'Unknown', '2025-03-17 09:47:13'),
(63, 1, 500.5, 120.3, 'sq_feet', 'New York', '2025-03-17 09:47:30'),
(64, 1, 145882694.48, 53382.76, 'meters', 'Unknown', '2025-03-17 09:52:18'),
(65, 1, 224025617.51, 60826.73, 'meters', 'Unknown', '2025-03-17 09:52:38'),
(66, 1, 342662093.12, 76965.05, 'meters', 'Unknown', '2025-03-17 09:57:05'),
(67, 1, 0, 20.66, 'kilometers', 'Unknown', '2025-03-18 04:00:46'),
(68, 1, 500.5, 120.3, 'sq_feet', 'New York', '2025-03-18 04:33:37'),
(69, 1, 161000927.95, 58084.21, 'meters', 'Unknown', '2025-03-18 04:45:40'),
(70, 1, 500.5, 120.3, 'sq_feet', 'New York', '2025-03-18 04:46:26'),
(71, 1, 172.554711, 54.42, 'kilometers', 'Unknown', '2025-03-18 04:47:49'),
(72, 2, 6196.83, 23331.08, 'acres', 'Unknown', '2025-03-18 05:21:25'),
(73, 1, 184867319.77, 52439.27, 'meters', 'Unknown', '2025-03-18 06:50:03'),
(74, 1, 4586196707.49, 154632.94, 'sq_feet', 'Unknown', '2025-03-19 04:14:50'),
(75, 1, 80471.46, 72625.39, 'acres', 'Unknown', '2025-03-19 04:53:28');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `mobile_number`, `password`, `created_at`) VALUES
(1, 'akash', '6382271269', '123', '2025-02-25 03:26:38'),
(2, 'mike', '7687898764', '678', '2025-02-25 04:31:19'),
(4, 'Logan', '8976789945', '567', '2025-02-25 04:35:10'),
(5, 'Loki', '8976789946', '567', '2025-02-25 04:36:01'),
(6, 'varun', '7678978678', '345', '2025-02-25 04:53:23'),
(7, 'laks', '8767856765', '777', '2025-02-25 04:57:48'),
(8, 'ako', '6545678987', '1234', '2025-02-25 05:16:49'),
(9, 'varshiki', '4628573190', '456', '2025-02-25 06:16:25'),
(10, 'virahini', '4682357190', '456', '2025-02-25 06:17:48'),
(12, 'akash1', '4656879321', '123', '2025-02-25 06:19:59'),
(13, 'virat', '7678987665', '676', '2025-02-25 06:21:35'),
(14, 'test4', '6383053175', 'test12', '2025-02-25 08:25:57'),
(15, 'new123', '6385279619', 'new123', '2025-02-25 08:30:41'),
(16, 'new1234', '6385279618', 'hello123', '2025-02-25 08:37:19'),
(17, 'new5', '6385279615', 'new5', '2025-02-25 09:10:53'),
(18, 'maith', '6383053111', 'new12', '2025-02-25 09:24:31'),
(19, 'jillo1123', '6594395385', 'jillo12345', '2025-02-26 03:22:49'),
(20, 'user12345', '6383053555', 'users12345', '2025-02-26 03:25:03'),
(21, 'newone123', '6383053456', 'new123', '2025-02-26 06:54:39'),
(22, 'vevs', '7777777777', '123', '2025-03-17 09:58:49'),
(23, 'dhoni', '8525656565', '012', '2025-03-18 04:06:10'),
(26, 'akash8', '4656879325', '123', '2025-03-19 04:22:31'),
(27, 'varshini', '1597824630', '123', '2025-03-19 04:22:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `measurements`
--
ALTER TABLE `measurements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `mobile_number` (`mobile_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `measurements`
--
ALTER TABLE `measurements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `measurements`
--
ALTER TABLE `measurements`
  ADD CONSTRAINT `measurements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `signup` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
