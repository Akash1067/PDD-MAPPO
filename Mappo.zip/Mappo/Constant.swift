//
//  Constant.swift
//  Mappo
//
//  Created by SAIL on 08/02/25.
//

import Foundation
import UIKit


class ServiceAPI: Codable{
    static var ipAddress = "https://9hkwlmn2-80.inc1.devtunnels.ms/Mappo/"
    static var login = ipAddress+"login.php"
    static var signup = ipAddress+"register.php"
    static var password = ipAddress+"forgotpassword.php"
    static var saveMeasurement = ipAddress+"savemeasurement.php"
    static var getmeasure = ipAddress+"getmeasure.php"
}

class ConstantData{
    static var loginResponse : LoginData?
}

extension UIViewController {
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
