//
//  ForgotResponseModel.swift
//  Mappo
//
//  Created by SAIL on 08/02/25.
//


import Foundation

// MARK: - ForgotResponseModel
struct ForgotResponseModel: Codable {
    let status: Bool
    let message: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let success: String
}
