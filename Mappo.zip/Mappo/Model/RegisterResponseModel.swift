//
//  RegisterResponseModel.swift
//  Mappo
//
//  Created by SAIL on 08/02/25.
//

import Foundation

// MARK: - RegisterResponseModel
struct RegisterResponseModel: Codable {
    let status: Bool
    let message, data: String
}
