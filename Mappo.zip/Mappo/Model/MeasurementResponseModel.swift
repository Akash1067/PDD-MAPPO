//
//  MeasurementResponseModel.swift
//  Mappo
//
//  Created by SAIL on 19/02/25.
//

import Foundation


// MARK: - GetMeasurements
struct MeasurementResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [MeasurementData]
}

// MARK: - Datum
struct MeasurementData: Codable {
    let id, userID: String
    let area, perimeter: Double
    let unit, place: String

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case area, perimeter, unit, place
    }
}


struct MeasurementPostModel: Codable {
    let status: Bool
    let message: String
    let data: MeasurementPostData
}

// MARK: - DataClass
struct MeasurementPostData: Codable {
    let id: Int
    let userID, area, perimeter, unit: String
    let place: String

    enum CodingKeys: String, CodingKey {
        case id
        case userID = "user_id"
        case area, perimeter, unit, place
    }
}
