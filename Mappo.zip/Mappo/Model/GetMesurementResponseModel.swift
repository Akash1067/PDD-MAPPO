//
//  GetMesurementResponseModel.swift
//  Mappo
//
//  Created by SAIL on 26/02/25.
//

import Foundation

struct Measurement: Codable {
    let id: Int
    let user_id: String
    let area: Double
    let perimeter: Double
    let unit: String
    let place: String
}

struct MeasurementModel: Codable {
    let status: Bool
    let message: String
    let data: [Measurement]?
    
    
}
