import Foundation

// MARK: - LoginResponseModel
struct LoginResponseModel: Codable {
    let status: Bool
    let message: String
    let data: LoginData
}

// MARK: - DataClass
struct LoginData: Codable {
    let username, mobileNumber: String
    let id : Int?

    enum CodingKeys: String, CodingKey {
        case username
        case mobileNumber = "mobile_number"
        case id
    }
}
