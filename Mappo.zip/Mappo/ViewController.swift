import UIKit
import MapKit
import CoreLocation
import MessageUI



class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    

    @IBOutlet weak var mapView: MKMapView!
    
    
    
    var locationManager = CLLocationManager()
    var currentMode: String = "" // "Fields" or "Distance"
    var selectedUnit: String = "meters"
    var points: [CLLocationCoordinate2D] = []
    var annotations: [MKPointAnnotation] = []
    var requiredPoints: Int = 0
    var measurementLabel: UILabel!
    let floatingMenu = UIView()
    let menuButton = UIButton()
    var menuVisible = false
    
    let searchBar = UISearchBar()


    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupLocationManager()
        mapView.delegate = self
        setupUIButtons()
        setupMeasurementLabel()
        setupFloatingMenu()
        setupMenuButton()
        setupSearchBar()
        addTapGesture()
        
    }
    // Function to fetch the user's current location
    func getCurrentLocation() -> CLLocationCoordinate2D? {
        guard let location = locationManager.location else {
            showAlert(title: "Error", message: "Unable to get current location")
            return nil
        }
        return location.coordinate
    }
    
    func isUserLoggedIn() -> Bool {
        return UserDefaults.standard.bool(forKey: "isLoggedIn")  // Modify based on your login logic
    }


    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        mapView.showsUserLocation = true
    }

    
    func setupMeasurementLabel() {
        measurementLabel = UILabel(frame: CGRect(x: 20, y: 115, width: 300, height: 20))
        measurementLabel.backgroundColor = UIColor.white
        measurementLabel.textAlignment = .center
        measurementLabel.layer.cornerRadius = 5
        measurementLabel.clipsToBounds = true
        measurementLabel.isHidden = true
        view.addSubview(measurementLabel)
    }
    
    var saveButton: UIButton! 

    func setupUIButtons() {
       
        let menuButton = UIButton(frame: CGRect(x: self.view.frame.width - 140, y: self.view.frame.height - 110, width: 120, height: 40))
        menuButton.layer.cornerRadius = 10
        menuButton.backgroundColor = .white
        menuButton.setTitle("Create New", for: .normal)
        menuButton.setTitleColor(.black, for: .normal)
        menuButton.addTarget(self, action: #selector(menuButtonClicked), for: .touchUpInside)
        self.view.addSubview(menuButton)

        let clearButton = UIButton(frame: CGRect(x: 20, y: self.view.frame.height - 110, width: 100, height: 40))
        clearButton.layer.cornerRadius = 10
        clearButton.backgroundColor = .white
        clearButton.setTitle("Clear", for: .normal)
        clearButton.setTitleColor(.red, for: .normal)
        clearButton.addTarget(self, action: #selector(clearButtonClicked), for: .touchUpInside)
        self.view.addSubview(clearButton)

        let undoButton = UIButton(frame: CGRect(x: self.view.frame.width - 255, y: self.view.frame.height - 110, width: 100, height: 40))
        undoButton.layer.cornerRadius = 10
        undoButton.backgroundColor = .white
        undoButton.setTitle("Undo", for: .normal)
        undoButton.setTitleColor(.blue, for: .normal)
        undoButton.addTarget(self, action: #selector(undoLastPoint), for: .touchUpInside)
        self.view.addSubview(undoButton)

        // Save Button (Initially Hidden)
        saveButton = UIButton(frame: CGRect(x:self.view.frame.width - 120, y: self.view.frame.height - 160, width: 100, height: 40))
        saveButton.layer.cornerRadius = 10
        saveButton.backgroundColor = .white
        saveButton.setTitle("Save", for: .normal)
        saveButton.setTitleColor(.green, for: .normal)
        saveButton.addTarget(self, action: #selector(saveMeasurement), for: .touchUpInside)
        saveButton.isHidden = true  // Hide initially
        self.view.addSubview(saveButton)
    }

    // MARK: - Setup Floating Menu
    func setupFloatingMenu() {    floatingMenu.frame = CGRect(x: 20, y: 160, width: 200, height: 210)
        floatingMenu.backgroundColor = .white
        floatingMenu.layer.cornerRadius = 12
        floatingMenu.layer.shadowColor = UIColor.black.cgColor
        floatingMenu.layer.shadowOpacity = 0.2
        floatingMenu.layer.shadowOffset = CGSize(width: 0, height: 4)
        floatingMenu.layer.shadowRadius = 6
        floatingMenu.isHidden = true
        
        let menuItems = ["Home", "My Measurements", "SOS Emergency", "Route Planner"]
        
        for (index, item) in menuItems.enumerated() {
            let button = UIButton(frame: CGRect(x: 0, y: CGFloat(index) * 50, width: 200, height: 60))
            button.setTitle(item, for: .normal)
            button.setTitleColor(.black, for: .normal)
            button.contentHorizontalAlignment = .center
            button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
            button.addTarget(self, action: #selector(menuItemTapped(_:)), for: .touchUpInside)
            floatingMenu.addSubview(button)
        }
        
        view.addSubview(floatingMenu)
        
    }

    func setupMenuButton() {menuButton.frame = CGRect(x: 20, y: 100, width: 45, height: 45)
        menuButton.setImage(UIImage(systemName: "line.horizontal.3"), for: .normal)
        menuButton.tintColor = .black
        menuButton.backgroundColor = .white
        menuButton.layer.cornerRadius = 10
        menuButton.layer.shadowOpacity = 0.2
        menuButton.layer.shadowOffset = CGSize(width: 0, height: 4)
        menuButton.layer.shadowRadius = 6
        menuButton.addTarget(self, action: #selector(toggleMenu), for: .touchUpInside)
        
        view.addSubview(menuButton)
    }


    func sendSOSViaSMS(message: String) {
        if MFMessageComposeViewController.canSendText() {
            let messageVC = MFMessageComposeViewController()
            messageVC.body = message
            messageVC.recipients = ["+911234567890"] // ✅ Replace with an actual emergency contact
            messageVC.messageComposeDelegate = self
            present(messageVC, animated: true, completion: nil)
        } else {
            showAlert(title: "Error", message: "SMS service is not available on this device.")
        }
    }
    func sendSOSViaWhatsApp(message: String) {
        let encodedMessage = message.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let whatsappURL = URL(string: "whatsapp://send?text=\(encodedMessage!)")

        if let url = whatsappURL, UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            showAlert(title: "Error", message: "WhatsApp is not installed on this device.")
        }
    }

    
    func setupSearchBar() {
        let searchContainer = UIView(frame: CGRect(x: 80, y: 100, width: view.frame.width - 145, height: 45))
        searchContainer.backgroundColor = .white
        searchContainer.layer.cornerRadius = 10
        searchContainer.layer.shadowOpacity = 0.2
        searchContainer.layer.shadowOffset = CGSize(width: 0, height: 2)
        searchContainer.layer.shadowRadius = 4
        searchContainer.clipsToBounds = false

        searchBar.frame = CGRect(x: 0, y: 0, width: searchContainer.frame.width, height: searchContainer.frame.height)
        searchBar.placeholder = "Search location"
        searchBar.delegate = self
        searchBar.backgroundImage = UIImage()  // Remove default background

        searchContainer.addSubview(searchBar)
        view.addSubview(searchContainer)
    }
    
    func saveMeasurements(userId: String, area: String, perimeter: String, unit: String, place: String) {
        // Define the parameters to send
        let param: [String: Any] = [
            "user_id": userId,
            "area": area,
            "perimeter": perimeter,
            "unit": unit,
            "place": place
        ]

        // Call the API using your APIHandler
        APIHandler.shared.postAPIValues(type: MeasurementPostModel.self, apiUrl: ServiceAPI.saveMeasurement, method: "POST", formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.status {
                        // ✅ Measurements saved successfully
                        self.showAlert(title: "Success", message: "Measurements saved successfully.")
                    } else {
                        self.showAlert(title: "Failure", message: response.message)
                    }

                case .failure(let error):
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }



    @objc func toggleMenu() { menuVisible.toggle()
        
        UIView.animate(withDuration: 0.3) {
            self.floatingMenu.alpha = self.menuVisible ? 1 : 0
            self.floatingMenu.isHidden = !self.menuVisible
            
        }
    }

    @objc func menuItemTapped(_ sender: UIButton) {
        guard let title = sender.titleLabel?.text else { return }

        switch title {
        case "Home":
            print("Home tapped")
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        case "My Measurements":
            print("My Measurements tapped")
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MeasurementsViewController") as! MeasurementsViewController
            self.navigationController?.pushViewController(vc, animated: true)

        case "SOS Emergency":
            sosButtonTapped() // ✅ Call SOS function

        case "Route Planner":
            print("Route Planner tapped")
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RoutePlannerViewController") as! RoutePlannerViewController
            self.navigationController?.pushViewController(vc, animated: true)
            

        default:
            break
        }
    }


    
    @objc func undoLastPoint() {
        guard !points.isEmpty else { return }
        
        // Remove last point
        points.removeLast()
        
        // Remove last annotation
        if let lastAnnotation = annotations.last {
            mapView.removeAnnotation(lastAnnotation)
            annotations.removeLast()
        }

        // Remove all overlays and redraw based on remaining points
        mapView.removeOverlays(mapView.overlays)
        
        if points.count > 1 {
            if currentMode == "Distance" {
                drawPolyline()
            } else if currentMode == "Fields" {
                drawPolygon()
            }
        } else {
            measurementLabel.isHidden = true
        }
    }



    @objc func menuButtonClicked() {
        askForMode()
    }

    func askForUnits() {
        let alert = UIAlertController(title: "Select Unit", message: nil, preferredStyle: .alert)

        // If Distance mode is selected, show only Meters and Kilometers
        let units = (currentMode == "Distance") ? ["Meters", "Kilometers"] : ["Meters", "Kilometers", "Acres", "Sq Feet", "Meter Square", "Kilometer Square"]
        
        for unit in units {
            alert.addAction(UIAlertAction(title: unit, style: .default, handler: { action in
                self.selectedUnit = action.title!.lowercased().replacingOccurrences(of: " ", with: "_")
                self.askForPoints()
            }))
        }

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true)
    }
    
    @objc func sosButtonTapped() {
        guard let coordinate = getCurrentLocation() else { return }

        let latitude = coordinate.latitude
        let longitude = coordinate.longitude

        // ✅ Use both Apple Maps & Google Maps links for better compatibility
        let appleMapsLink = "http://maps.apple.com/?q=\(latitude),\(longitude)"
        let googleMapsLink = "https://www.google.com/maps/search/?api=1&query=\(latitude),\(longitude)"

        let message = """
        🚨 EMERGENCY SOS 🚨
        I need help! Here is my live location:

        📍 Apple Maps: \(appleMapsLink)

        🌍 Google Maps: \(googleMapsLink)
        """

        let alert = UIAlertController(title: "Send SOS", message: "Choose how to share your emergency location.", preferredStyle: .actionSheet)

        alert.addAction(UIAlertAction(title: "Send via SMS", style: .default, handler: { _ in
            self.sendSOSViaSMS(message: message)
        }))
        
        alert.addAction(UIAlertAction(title: "Send via WhatsApp", style: .default, handler: { _ in
            self.sendSOSViaWhatsApp(message: message)
        }))

        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        present(alert, animated: true, completion: nil)
    }



    func askForMode() {
        let alert = UIAlertController(title: "Select Measurement Type", message: nil, preferredStyle: .alert)
        let options = ["Fields", "Distance"]
        
        for option in options {
            alert.addAction(UIAlertAction(title: option, style: .default, handler: { action in
                self.currentMode = action.title!
                self.askForUnits()
            }))
        }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true)
    }

    func askForPoints() {
        let alert = UIAlertController(title: "How many points do you want to add?", message: nil, preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = "Enter number of points"
            textField.keyboardType = .numberPad
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            if let input = alert.textFields?.first?.text, let count = Int(input), count > 1 {
                self.requiredPoints = count
                self.points.removeAll()
            }
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true)
    }

    func addTapGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleMapTap(_:)))
        mapView.addGestureRecognizer(tapGesture)
    }

    @objc func handleMapTap(_ gesture: UITapGestureRecognizer) {
        guard points.count < requiredPoints else { return }

        let location = gesture.location(in: mapView)
        let coordinate = mapView.convert(location, toCoordinateFrom: mapView)
        
        points.append(coordinate)
        addAnnotation(at: coordinate)

        if points.count == requiredPoints {
            if currentMode == "Distance" {
                drawPolyline()
            } else if currentMode == "Fields" {
                drawPolygon()
            }
        }
    }
    
    func addAnnotation(at coordinate: CLLocationCoordinate2D) {
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = "Lat: \(coordinate.latitude), Lng: \(coordinate.longitude)"
        mapView.addAnnotation(annotation)
        annotations.append(annotation)
    }

    func drawPolyline() {
        let polyline = MKPolyline(coordinates: points, count: points.count)
        mapView.addOverlay(polyline)

        let distance = distanceBetween(points: points)  // Get distance
        let formattedDistance = formatValue(distance, unit: selectedUnit, isPerimeter: true)

        // Show only Distance in Distance Mode
        showMeasurementLabel(text: "Distance: \(formattedDistance)")
    }



  

    func drawPolygon() {
        let polygon = MKPolygon(coordinates: points, count: points.count)
        mapView.addOverlay(polygon)

        let area = areaOfPolygon(points: points)  // Calculate area
        let perimeter = perimeterOfPolygon(points: points)  // Calculate perimeter

        let formattedArea = formatValue(area, unit: selectedUnit, isPerimeter: false)
        let formattedPerimeter = formatValue(perimeter, unit: selectedUnit, isPerimeter: true)

        let labelText = "Area: \(formattedArea)\nPerimeter: \(formattedPerimeter)"

        showMeasurementLabel(text: labelText)
    }


    
    func perimeterOfPolygon(points: [CLLocationCoordinate2D]) -> Double {
        guard points.count > 1 else { return 0 }  // Need at least 2 points
        var perimeter: Double = 0
        for i in 0..<points.count {
            let nextIndex = (i + 1) % points.count  // Loop back to the first point
            let loc1 = CLLocation(latitude: points[i].latitude, longitude: points[i].longitude)
            let loc2 = CLLocation(latitude: points[nextIndex].latitude, longitude: points[nextIndex].longitude)
            perimeter += loc1.distance(from: loc2)  // Add distance between each pair of points
        }
        return perimeter
    }
    
    




    @objc func clearButtonClicked() {
        points.removeAll()
        requiredPoints = 0
        mapView.removeAnnotations(annotations)
        annotations.removeAll()
        mapView.removeOverlays(mapView.overlays)
        measurementLabel.isHidden = true
        if let existingBlurView = view.viewWithTag(999) {
                existingBlurView.removeFromSuperview()
            }
    }

    func showMeasurementLabel(text: String) {
        if let existingBlurView = view.viewWithTag(999) {
            existingBlurView.removeFromSuperview()
        }

        // Create a blur effect background
        let blurEffect = UIBlurEffect(style: .light)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = CGRect(x: 75, y: 150, width: 300, height: 75) // Increased height for multi-line text
        blurEffectView.layer.cornerRadius = 10
        blurEffectView.clipsToBounds = true
        blurEffectView.tag = 999 // Assign a tag to identify & remove later

        // Create the label
        measurementLabel = UILabel(frame: blurEffectView.bounds)
        measurementLabel.textAlignment = .center
        measurementLabel.textColor = .black
        measurementLabel.font = UIFont.boldSystemFont(ofSize: 20)
        measurementLabel.numberOfLines = 3  // Allow multi-line text
        measurementLabel.text = text

        // Add the label inside the blur effect view
        blurEffectView.contentView.addSubview(measurementLabel)

        // Add the blurred effect view to the main view
        view.addSubview(blurEffectView)

        // Animate appearance
        blurEffectView.alpha = 0
        UIView.animate(withDuration: 0.3) {
            blurEffectView.alpha = 1
        }

        // Show Save Button after displaying measurement
        saveButton.isHidden = false
    }
    
    
  
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        if isUserLoggedIn() {
            //saveMeasurementsToAPI()
        } else {
            showAlert(title: "Login Required", message: "Please log in to save measurements.")
        }
    }
    
    
    @objc func saveMeasurement() {
        guard !points.isEmpty else {
            showAlert(title: "Error", message: "No measurement to save.")
            return
        }
        
        if let userId = ConstantData.loginResponse?.id {
            let id = String(userId)
            let area = areaOfPolygon(points: points)
            let perimeter = perimeterOfPolygon(points: points)
            
            let formattedArea = formatValue(area, unit: selectedUnit, isPerimeter: false)
            let formattedPerimeter = formatValue(perimeter, unit: selectedUnit, isPerimeter: true)

        
            saveMeasurements(userId: id, area: formattedArea, perimeter: formattedPerimeter, unit: selectedUnit, place: "Unknown")
        } else {
            showLoginAlert()
        }
    }

    
    func showLoginAlert() {
        let alert = UIAlertController(title: "Login Required", message: "You need to log in to save measurements.", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Login", style: .default, handler: { _ in
            self.navigateToLogin()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        present(alert, animated: true)
    }
    
    func navigateToLogin() {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginScreenViewController") as! LoginScreenViewController
        self.navigationController?.pushViewController(loginVC, animated: true)
    }


    func distanceBetween(points: [CLLocationCoordinate2D]) -> Double {
        guard points.count > 1 else { return 0 }
        var totalDistance: Double = 0
        for i in 1..<points.count {
            let loc1 = CLLocation(latitude: points[i-1].latitude, longitude: points[i-1].longitude)
            let loc2 = CLLocation(latitude: points[i].latitude, longitude: points[i].longitude)
            totalDistance += loc1.distance(from: loc2)
        }
        return totalDistance
    }

    func areaOfPolygon(points: [CLLocationCoordinate2D]) -> Double {
        guard points.count > 2 else { return 0 }

        let earthRadius: Double = 6378137.0  // Earth's radius in meters
        var area: Double = 0
        let count = points.count

        for i in 0..<count {
            let j = (i + 1) % count
            let xi = points[i].longitude * .pi / 180.0 * earthRadius * cos(points[i].latitude * .pi / 180.0)
            let yi = points[i].latitude * .pi / 180.0 * earthRadius
            let xj = points[j].longitude * .pi / 180.0 * earthRadius * cos(points[j].latitude * .pi / 180.0)
            let yj = points[j].latitude * .pi / 180.0 * earthRadius

            area += (xi * yj) - (xj * yi)
        }
        return abs(area / 2.0)
    }

    
    func formatValue(_ value: Double, unit: String, isPerimeter: Bool) -> String {
        if isPerimeter {
            // Format perimeter based on selected unit
            switch unit {
            case "meters":
                return String(format: "%.2f m", value)
            case "kilometers":
                return String(format: "%.2f km", value / 1000)
            default:
                return String(format: "%.2f m", value)  // Perimeter always shown in meters
            }
        } else {
            // Format area based on selected unit
            switch unit {
            case "meters", "meter_square":
                return String(format: "%.2f m²", value)
            case "kilometers", "kilometer_square":
                return String(format: "%.6f km²", value / 1_000_000)  // Convert from m² to km²
            case "acres":
                return String(format: "%.2f acres", value / 4046.86)
            case "sq_feet":
                return String(format: "%.2f sq ft", value * 10.7639)
            default:
                return String(format: "%.2f", value)
            }
        }
    }

    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = .blue
            renderer.lineWidth = 2
            return renderer
        } else if let polygon = overlay as? MKPolygon {
            let renderer = MKPolygonRenderer(polygon: polygon)
            renderer.fillColor = UIColor.red.withAlphaComponent(0.3)
            return renderer
        }
        return MKOverlayRenderer()
    }
}


extension ViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()

        guard let query = searchBar.text, !query.isEmpty else { return }

        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = query

        let search = MKLocalSearch(request: searchRequest)
        search.start { response, error in
            guard let response = response, let firstItem = response.mapItems.first else {
                self.showAlert(title: "Not Found", message: "Location not found")
                return
            }

            let coordinate = firstItem.placemark.coordinate
            let region = MKCoordinateRegion(center: coordinate, latitudinalMeters: 5000, longitudinalMeters: 5000)

            self.mapView.setRegion(region, animated: true)
            self.addSearchAnnotation(at: coordinate, title: query)
        }
    }

    func addSearchAnnotation(at coordinate: CLLocationCoordinate2D, title: String) {
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = title
        mapView.addAnnotation(annotation)
    }
}

extension ViewController: MFMessageComposeViewControllerDelegate {
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        controller.dismiss(animated: true, completion: nil)
    }
}
