//
//  MeasurementsViewController.swift
//  Mappo
//
//  Created by SAIL on 12/02/25.
//

import UIKit

class MeasurementsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var measurements = [MeasurementData]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let cel = UINib(nibName: "MeasurementsTableViewCell", bundle: nil)
        tableView.register(cel, forCellReuseIdentifier: "MeasurementsTableViewCell")
        
        tableView.delegate = self
        tableView.dataSource = self
        
        

        fetchMeasurementsFromAPI()
    }
   
    
    func fetchMeasurementsFromAPI() {
              

        APIHandler.shared.getAPIValues(type: MeasurementResponseModel.self, apiUrl: ServiceAPI.getmeasure, method: "GET") { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.status {
                      
                        let val = response.data.filter {$0.userID == "\(ConstantData.loginResponse?.id ?? 0)"}
                        self.measurements = val
                        self.tableView.reloadData()
                        
                    
                    } else {
                        self.showAlert(title: "Error", message: response.message)
                    }

                case .failure(let error):
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
        }

       


    @IBAction func SavemeasurementTapped(_ sender: Any) {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
  
}
extension MeasurementsViewController: UITableViewDelegate,UITableViewDataSource {
    // ✅ UITableView Data Source Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return measurements.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MeasurementsTableViewCell", for: indexPath) as! MeasurementsTableViewCell
       let data = measurements[indexPath.row]
        cell.areaLb.text = "\(data.area)"
        cell.perimeterLbl.text = "\(data.perimeter)"
        cell.unitLbl.text = data.unit
        cell.place.text = data.place
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }

}
