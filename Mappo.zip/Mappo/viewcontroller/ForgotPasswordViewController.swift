import UIKit

class ForgotPasswordViewController: UIViewController {
    
    @IBOutlet weak var mobile_numberTF: UITextField!
    @IBOutlet weak var confirm_passwordTF: UITextField!
    @IBOutlet weak var new_passwordTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func changepassTapped(_ sender: Any) {
        let mobile_number = mobile_numberTF.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let new_password = new_passwordTF.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let confirm_password = confirm_passwordTF.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        
        // Check if all fields are empty
        if mobile_number.isEmpty && new_password.isEmpty && confirm_password.isEmpty {
            showAlert(message: "Please enter valid details.")
            return
        }
        
        // Validate individual fields
        if mobile_number.isEmpty {
            showAlert(message: "Please enter your mobile number.")
            return
        }
        
        if new_password.isEmpty {
            showAlert(message: "Please enter a new password.")
            return
        }
        
        if confirm_password.isEmpty {
            showAlert(message: "Please confirm your password.")
            return
        }
        
        if new_password != confirm_password {
            showAlert(message: "Passwords do not match.")
            return
        }
        
        let param = [
            "mobile_number": mobile_number,
            "new_password": new_password,
            "confirm_password": confirm_password
        ]
        
        APIHandler.shared.postAPIValues(type: ForgotResponseModel.self, apiUrl: ServiceAPI.password, method: "POST", formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    self.showAlert(message: response.message, popViewController: true)
                    
                case .failure:
                    self.showAlert(message: "Failed to update password. Please try again.")
                }
            }
        }
    }
    
    // Function to show alert messages
    func showAlert(message: String, popViewController: Bool = false) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { _ in
            if popViewController {
                self.navigationController?.popViewController(animated: true)
            }
        }
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    
}

