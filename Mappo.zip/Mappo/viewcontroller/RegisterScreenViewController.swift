//
//  RegisterScreenViewController.swift
//  MappoUITests
//
//  Created by SAIL on 07/02/25.
//

import UIKit

class RegisterScreenViewController: UIViewController {

    @IBOutlet weak var re_enter_passwordTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var mobile_numberTF: UITextField!
    @IBOutlet weak var usernameTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
            view.addGestureRecognizer(tapGesture)
    }
    
    @IBAction func registertapped(_ sender: Any) { // Ensure this matches your storyboard connection
        
        // Check if all fields are empty
        if usernameTF.text?.isEmpty == true &&
            passwordTF.text?.isEmpty == true &&
            mobile_numberTF.text?.isEmpty == true &&
            re_enter_passwordTF.text?.isEmpty == true {
            showAlert(title: "Error", message: "Please enter the required fields.")
            return
        }
        
        // Validate each field separately
        guard let username = usernameTF.text, !username.isEmpty else {
            showAlert(title: "Error", message: "Username is required.")
            return
        }
        
        guard let password = passwordTF.text, !password.isEmpty else {
            showAlert(title: "Error", message: "Password is required.")
            return
        }
        
        guard let mobile_number = mobile_numberTF.text, !mobile_number.isEmpty else {
            showAlert(title: "Error", message: "Mobile number is required.")
            return
        }
        
        guard let re_enter_password = re_enter_passwordTF.text, !re_enter_password.isEmpty else {
            showAlert(title: "Error", message: "Please re-enter your password.")
            return
        }
        
        // Check if passwords match
        guard password == re_enter_password else {
            showAlert(title: "Error", message: "Passwords do not match.")
            return
        }
        
        let param = ["username": username, "password": password, "mobile_number": mobile_number, "re_enter_password": re_enter_password]
        
        APIHandler.shared.postAPIValues(type: RegisterResponseModel.self, apiUrl: ServiceAPI.signup, method: "POST", formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print(response)
                    self.showAlert(title: "Success", message: "Registration successful!", completion: {
                        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginScreenViewController") as! LoginScreenViewController
                        self.navigationController?.pushViewController(vc, animated: true)
                    })
                    
                case .failure(_):
                    self.showAlert(title: "Error", message: "Registration failed. Please try again.")
                }
            }
        }
    }
    
    // 🔹 Helper function to show alert messages
    func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            completion?() // Executes completion handler if provided
        })
        present(alert, animated: true)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

