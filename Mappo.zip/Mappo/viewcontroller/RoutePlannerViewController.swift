import UIKit
import MapKit
import CoreLocation

class RoutePlannerViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, UISearchBarDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    var startCoordinate: CLLocationCoordinate2D?
    var endCoordinate: CLLocationCoordinate2D?
    var routeOverlay: MKPolyline?
    var routes: [MKRoute] = []  // Store multiple routes
    var routeInfoLabel: UILabel!
    var startButton: UIButton!
    var routeSelector: UISegmentedControl!
    let searchBar = UISearchBar()
    var isNavigating = false

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupLocationManager()
        mapView.delegate = self
        
        // Add Tap Gesture for Start & End Points
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleMapTap(_:)))
        mapView.addGestureRecognizer(tapGesture)
        
        // Setup UI Elements
        setupRouteInfoLabel()
        setupStartButton()
        setupClearRouteButton()
        setupRouteSelector()
        setupSearchBar()
        
    }
    
    // MARK: - Setup Location Manager
    func setupLocationManager() {
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        mapView.showsUserLocation = true
    }

    // MARK: - Setup Route Info Label
    func setupRouteInfoLabel() {
        routeInfoLabel = UILabel(frame: CGRect(x: 20, y: self.view.frame.height - 120, width: self.view.frame.width - 40, height: 50))
        routeInfoLabel.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        routeInfoLabel.textColor = .white
        routeInfoLabel.textAlignment = .center
        routeInfoLabel.layer.cornerRadius = 10
        routeInfoLabel.clipsToBounds = true
        routeInfoLabel.text = "Tap to select route"
        self.view.addSubview(routeInfoLabel)
    }
    
    func setupSearchBar() {
        searchBar.frame = CGRect(x: 20, y: 103, width: view.frame.width - 90, height: 45)
        searchBar.placeholder = "Search location..."
        searchBar.delegate = self
        searchBar.barStyle = .default
        searchBar.backgroundColor = .white


        // Apply corner radius to the search bar's text field
        searchBar.searchTextField.layer.cornerRadius = 10
        searchBar.searchTextField.layer.masksToBounds = true
        
        // Remove search bar background to make the corner radius more effective
        searchBar.backgroundImage = UIImage()
        searchBar.layer.cornerRadius = 10
        searchBar.layer.masksToBounds = true

        view.addSubview(searchBar)
    }

    // MARK: - UISearchBar Delegate Methods
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder() // Hide keyboard
        searchForLocation(searchBar.text)
    }

    func searchForLocation(_ query: String?) {
        guard let query = query, !query.isEmpty else { return }
        
        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = query
        searchRequest.region = mapView.region  // Search within the visible map area
        
        let search = MKLocalSearch(request: searchRequest)
        search.start { response, error in
            guard let response = response, error == nil else {
                print("Search error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            let mapItems = response.mapItems
            guard let firstItem = mapItems.first else { return }
            
            self.addAnnotation(at: firstItem.placemark.coordinate, title: firstItem.name ?? "Search Result")
            self.mapView.setCenter(firstItem.placemark.coordinate, animated: true)
        }
    }


    
    // MARK: - Setup Start Button
    func setupStartButton() {
        startButton = UIButton(frame: CGRect(x: 20, y: self.view.frame.height - 160, width: 120, height: 30))
        startButton.setTitle("Start", for: .normal)
        startButton.backgroundColor = .tintColor
        startButton.setTitleColor(.white, for: .normal)
        startButton.layer.cornerRadius = 10
        self.view.addSubview(startButton)
        startButton.isHidden = true  // Initially hide the button
    }
    
    // MARK: - Show Start Button When Route Is Ready
    
    // MARK: - Start Navigation Mode
   
    
    func followUserLocation() {
        mapView.setUserTrackingMode(.followWithHeading, animated: true)
    }
    
    

    // MARK: - Setup Clear Route Button
    func setupClearRouteButton() {
        let clearButton = UIButton(frame: CGRect(x: 250, y: self.view.frame.height - 160, width: 100, height: 30))
        clearButton.setTitle("Clear Route", for: .normal)
        clearButton.backgroundColor = .white
        clearButton.setTitleColor(.red, for: .normal)
        clearButton.layer.cornerRadius = 10
        clearButton.addTarget(self, action: #selector(resetRoute), for: .touchUpInside)
        view.addSubview(clearButton)
    }

    // MARK: - Setup Route Selector
    func setupRouteSelector() {
        routeSelector = UISegmentedControl()
        routeSelector.frame = CGRect(x: 20, y: self.view.frame.height - 200, width: self.view.frame.width - 40, height: 30)
        routeSelector.backgroundColor = .white
        routeSelector.addTarget(self, action: #selector(routeSelectionChanged), for: .valueChanged)
        self.view.addSubview(routeSelector)

    }
    
    

    // MARK: - Handle Tap to Select Start & End Points
    @objc func handleMapTap(_ gesture: UITapGestureRecognizer) {
        let touchPoint = gesture.location(in: mapView)
        let coordinate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        
        if startCoordinate == nil {
            startCoordinate = coordinate
            addAnnotation(at: coordinate, title: "Start Point")
        } else if endCoordinate == nil {
            endCoordinate = coordinate
            addAnnotation(at: coordinate, title: "End Point")
            drawRoute()
        } else {
            resetRoute()
            startCoordinate = coordinate
            addAnnotation(at: coordinate, title: "Start Point")
        }
    }
    
    // MARK: - Add Annotation on Map
    func addAnnotation(at coordinate: CLLocationCoordinate2D, title: String) {
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = title
        mapView.addAnnotation(annotation)
    }

    // MARK: - Draw Route Between Start & End Points
    func drawRoute() {
        guard let start = startCoordinate, let end = endCoordinate else { return }

        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: start))
        request.destination = MKMapItem(placemark: MKPlacemark(coordinate: end))
        request.transportType = .automobile
        request.requestsAlternateRoutes = true

        let directions = MKDirections(request: request)
        directions.calculate { [weak self] response, error in
            guard let self = self, let response = response else { return }

            self.routes = response.routes
            self.mapView.removeOverlays(self.mapView.overlays)

            for (index, route) in self.routes.enumerated() {
                let polyline = route.polyline
                polyline.title = "Route \(index + 1)"
                self.mapView.addOverlay(polyline)
            }

            self.updateRouteSelector()

            if let shortestRoute = self.routes.min(by: { $0.distance < $1.distance }) {
                self.selectRoute(route: shortestRoute)
            }
        }
    }

    // MARK: - Update Route Selector UI
    func updateRouteSelector() {
        routeSelector.removeAllSegments()
        for (index, _) in routes.enumerated() {
            routeSelector.insertSegment(withTitle: "Route \(index + 1)", at: index, animated: false)
        }
        routeSelector.selectedSegmentIndex = 0
    }

    // MARK: - Handle Route Selection
    @objc func routeSelectionChanged() {
        let selectedIndex = routeSelector.selectedSegmentIndex
        if selectedIndex < routes.count {
            selectRoute(route: routes[selectedIndex])
        }
    }

    func selectRoute(route: MKRoute) {
        if let existingRoute = routeOverlay {
            mapView.removeOverlay(existingRoute)
        }
        routeOverlay = route.polyline
        mapView.addOverlay(route.polyline)

        let distance = route.distance / 1000  // Convert to kilometers
        let travelTime = route.expectedTravelTime / 60  // Convert to minutes
        updateRouteInfo(distance: distance, time: travelTime)
    }

    // MARK: - Update Route Information Label
    func updateRouteInfo(distance: Double, time: Double) {
        routeInfoLabel.text = "Distance: \(String(format: "%.2f", distance)) km | Time: \(String(format: "%.0f", time)) min"
    }

    // MARK: - Reset Route
    @objc func resetRoute() {
        mapView.removeOverlays(mapView.overlays)
        mapView.removeAnnotations(mapView.annotations)
        startCoordinate = nil
        endCoordinate = nil
        routeInfoLabel.text = "Tap to select route"
        startButton.isHidden = true
        routeSelector.removeAllSegments()
        isNavigating = false
    }

    // MARK: - MapView Renderer
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let polyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: polyline)
            renderer.strokeColor = .blue
            renderer.lineWidth = 5
            return renderer
        }
        return MKOverlayRenderer()
    }

    // MARK: - Navigation: Track User Location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard isNavigating, let location = locations.last else { return }

        let userLocation = CLLocation(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)

        // Stop navigation when the user reaches the destination
        if let end = endCoordinate {
            let destinationLocation = CLLocation(latitude: end.latitude, longitude: end.longitude)
            if userLocation.distance(from: destinationLocation) < 50 {  // 50 meters threshold
                finishNavigation()
            }
        }

        // Update map to follow user location
        let region = MKCoordinateRegion(center: userLocation.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
        mapView.setRegion(region, animated: true)
    }

    func finishNavigation() {
        isNavigating = false
        startButton.setTitle("Start", for: .normal)
        startButton.backgroundColor = .blue
        startButton.isEnabled = true
        locationManager.stopUpdatingLocation()
        routeInfoLabel.text = "You have reached your destination!"
    }
}
