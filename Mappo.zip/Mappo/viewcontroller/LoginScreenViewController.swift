
//
//  LoginScreenViewController.swift
//  MappoUITests
//
//  Created by SAIL on 07/02/25.
//

import UIKit

class LoginScreenViewController: UIViewController {
    
    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
    }
    
    @IBAction func loginTapped(_ sender: Any) {
        guard let mobileNumber = userNameTF.text, !mobileNumber.isEmpty else {
            showAlert(title: "Error", message: "Mobile Number is required.")
            return
        }

        guard let password = passwordTF.text, !password.isEmpty else {
            showAlert(title: "Error", message: "Password is required.")
            return
        }

        // ✅ Updated parameter names to match the PHP API
        let param = ["mobile_number": mobileNumber, "password": password]

        APIHandler.shared.postAPIValues(type: LoginResponseModel.self, apiUrl: ServiceAPI.login, method: "POST", formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.status {
                        // ✅ Login Successful, save user data
                        ConstantData.loginResponse = response.data
                        
                        // ✅ Navigate to Home Screen (ViewController)
                        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as! ViewController
                        self.navigationController?.pushViewController(vc, animated: true)
                    } else {
                        self.handleLoginError(response.message)
                    }

                case .failure(let error):
                    self.showAlert(title: "Error", message: error.localizedDescription)
                }
            }
        }
    }

    
    // 🔹 Handles specific login errors
    private func handleLoginError(_ message: String) {
        if message.lowercased().contains("username not found") {
            showAlert(title: "Error", message: "Wrong username. Please check and try again.")
        } else if message.lowercased().contains("incorrect password") {
            showAlert(title: "Error", message: "Wrong password. Please try again.")
        } else {
            showAlert(title: "Error", message: message) // Default error message
        }
    }

    // 🔹 Helper function to show alerts
   
    
    @IBAction func forgotpasswordTapped(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ForgotPasswordViewController") as! ForgotPasswordViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func RegisternowTapped(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RegisterScreenViewController") as! RegisterScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
