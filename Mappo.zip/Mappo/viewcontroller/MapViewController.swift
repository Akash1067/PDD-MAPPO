import UIKit
import MapKit

class MapViewController: UIViewController {

    // MARK: - UI Elements
    let mapView = MKMapView()
    let floatingMenu = UIView()
    let menuButton = UIButton()
    var menuVisible = false

    override func viewDidLoad() {
        super.viewDidLoad()
        setupMapView()
        setupFloatingMenu()
        setupMenuButton()
        setupBottomButtons()
    }
    
    func setupMapView() {
        mapView.frame = view.bounds
        mapView.showsUserLocation = true
        view.addSubview(mapView)
    }

    func setupFloatingMenu() {
        floatingMenu.frame = CGRect(x: 20, y: 80, width: 250, height: 250)
        floatingMenu.backgroundColor = .white
        floatingMenu.layer.cornerRadius = 12
        floatingMenu.layer.shadowColor = UIColor.black.cgColor
        floatingMenu.layer.shadowOpacity = 0.2
        floatingMenu.layer.shadowOffset = CGSize(width: 0, height: 4)
        floatingMenu.layer.shadowRadius = 6
        floatingMenu.isHidden = true
        
        let menuItems = ["Home", "My Measurements", "Location", "Route Planner", "Privacy Policy"]
        
        for (index, item) in menuItems.enumerated() {
            let button = UIButton(frame: CGRect(x: 0, y: CGFloat(index) * 50, width: 250, height: 60))
            button.setTitle(item, for: .normal)
            button.setTitleColor(.black, for: .normal)
            button.contentHorizontalAlignment = .left
            button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
            button.addTarget(self, action: #selector(menuItemTapped(_:)), for: .touchUpInside)
            floatingMenu.addSubview(button)
        }
        
        view.addSubview(floatingMenu)
    }
    
    func setupMenuButton() {
        menuButton.frame = CGRect(x: 20, y: 40, width: 50, height: 50)
        menuButton.setImage(UIImage(systemName: "line.horizontal.3"), for: .normal)
        menuButton.tintColor = .black
        menuButton.backgroundColor = .white
        menuButton.layer.cornerRadius = 25
        menuButton.layer.shadowOpacity = 0.2
        menuButton.layer.shadowOffset = CGSize(width: 0, height: 4)
        menuButton.layer.shadowRadius = 6
        menuButton.addTarget(self, action: #selector(toggleMenu), for: .touchUpInside)
        
        view.addSubview(menuButton)
    }
    
    func setupBottomButtons() {
        let clearButton = UIButton(frame: CGRect(x: 20, y: view.frame.height - 80, width: 100, height: 40))
        clearButton.setTitle("Clear", for: .normal)
        clearButton.setTitleColor(.red, for: .normal)
        clearButton.backgroundColor = .white
        clearButton.layer.cornerRadius = 8
        clearButton.addTarget(self, action: #selector(clearTapped), for: .touchUpInside)
        view.addSubview(clearButton)
        
        let createButton = UIButton(frame: CGRect(x: view.frame.width - 140, y: view.frame.height - 80, width: 120, height: 40))
        createButton.setTitle("Create New", for: .normal)
        createButton.setTitleColor(.black, for: .normal)
        createButton.backgroundColor = .white
        createButton.layer.cornerRadius = 8
        createButton.addTarget(self, action: #selector(createTapped), for: .touchUpInside)
        view.addSubview(createButton)
    }

    @objc func toggleMenu() {
        menuVisible.toggle()
        UIView.animate(withDuration: 0.3) {
            self.floatingMenu.alpha = self.menuVisible ? 1 : 0
            self.floatingMenu.isHidden = !self.menuVisible
        }
    }

    @objc func menuItemTapped(_ sender: UIButton) {
        guard let title = sender.titleLabel?.text else { return }
        print("\(title) tapped")
        toggleMenu()
    }

    @objc func clearTapped() {
        print("Clear tapped")
        mapView.removeOverlays(mapView.overlays)
    }

    @objc func createTapped() {
        print("Create New tapped")
    }
}

