//
//  SplashScreenViewController.swift
//  Mappo
//
//  Created by SAIL on 08/02/25.
//

import UIKit

class SplashScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  
    @IBAction func loginTapped(_ sender: Any) {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginScreenViewController") as! LoginScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func registerTapped(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(withIdentifier: "RegisterScreenViewController") as! RegisterScreenViewController
        self.navigationController?
            .pushViewController(vc, animated: true)
    }
    
    @IBAction func GuestBtnTapped(_ sender: Any) {
        let vc = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?
            .pushViewController(vc, animated: true)
    }
    
}
